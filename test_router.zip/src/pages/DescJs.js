import React from 'react';

function DescJs()
{
    return (
        <p>
            Javascript is .....
        </p>
    );
}

export default DescJs;