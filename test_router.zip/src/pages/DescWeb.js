import React from 'react';

function DescWeb()
{
    return (
        <p>
            Web is .....
        </p>
    );
}

export default DescWeb;