import React from 'react';

function DescHtml()
{
    return (
        <p>
            Html is .....
        </p>
    );
}

export default DescHtml;