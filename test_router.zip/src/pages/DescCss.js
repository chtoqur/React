import React from 'react';

function DescCss()
{
    return (
        <p>
            Css is .....
        </p>
    );
}

export default DescCss;